export const environment = {
  APP_ID: '735141',
  ACCESS_KEY: '9PlNlwFKhQWu_2nfA8hrqU8f8f1pvCZzXhEHjo9kY9Y',
  SECRET_KEY: 'l_KLrXW9X0K7YKnDl0PPPX6rnBWvpw-cnwjlVFSPLvw',
};

import { Component } from '@angular/core';

@Component({
  selector: 'app-artists',
  imports: [],
  templateUrl: './artists.component.html',
  styleUrl: './artists.component.scss'
})
export class ArtistsComponent {

}
